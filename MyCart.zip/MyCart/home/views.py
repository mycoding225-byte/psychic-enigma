from django.shortcuts import render, get_object_or_404
from django.db.models import Q
from .models import Product, Category
from django.db.models import F


def home(request):
    category_id = request.GET.get("category")
    query = request.GET.get("q", "").strip()

    categories = Category.objects.all()
    products = Product.objects.all()

    if category_id:
        products = products.filter(category_id=category_id)

    if query:
        products = products.filter(
            Q(name__icontains=query) |
            Q(description__icontains=query) |
            Q(brand__icontains=query)
        )

    return render(request, "index.html", {
        "products": products,
        "categories": categories,
        "query": query,
        "cart_count": 0
    })


def search(request):
    query = request.GET.get("q", "").strip()

    products = Product.objects.all()

    if query:
        products = products.filter(
            Q(name__icontains=query) |
            Q(description__icontains=query) |
            Q(brand__icontains=query)
        )

    return render(request, "search.html", {
        "products": products,
        "query": query
    })


def product_detail(request, id):
    product = get_object_or_404(Product, id=id)

    return render(request, "product_detail.html", {
        "product": product
    })
    

def shop(request):
    products = Product.objects.all()
    return render(request, "shop.html", {"products": products})


def categories(request):
    categories = Category.objects.all()
    return render(request, "categories.html", {"categories": categories})


def category_products(request, id):
    category = get_object_or_404(Category, id=id)
    products = Product.objects.filter(category=category)

    return render(request, "category.html", {
        "category": category,
        "products": products
    })



def deals(request):
    products = Product.objects.filter(old_price__gt=F('price'))
    return render(request, 'deals.html', {'products': products})

def contact(request):
    return render(request, "contact.html")


def cart(request):
    return render(request, "cart.html")
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),

    # SHOP
    path('shop/', views.shop, name='shop'),

    # CATEGORIES
    path('categories/', views.categories, name='categories'),
    path('category/<int:id>/', views.category_products, name='category_products'),

    # SEARCH
    path('search/', views.search, name='search'),

    # PRODUCT
    path('product/<int:id>/', views.product_detail, name='product_detail'),

    # CART
    path('cart/', views.cart, name='cart'),

    # DEALS
    path('deals/', views.deals, name='deals'),

    # CONTACT
    path('contact/', views.contact, name='contact'),
]
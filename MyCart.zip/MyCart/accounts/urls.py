from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', views.login_page, name='login'),
    path('logout/', views.logout_page, name='logout'),

    path('cart/', views.cart, name='cart'),
    path('add-to-cart/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('remove-cart/<int:item_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('increase/<int:item_id>/', views.increase_quantity, name='increase_quantity'),
    path('decrease/<int:item_id>/', views.decrease_quantity, name='decrease_quantity'),
    path(
    'checkout/',
    views.checkout,
    name='checkout'
),
    path(
    'my-orders/',
    views.my_orders,
    name='my_orders'
),
path(
    "address/",
    views.address,
    name="address"
),

path(
    'order/<int:order_id>/',
    views.order_detail,
    name='order_detail'
),


path('wishlist/', views.wishlist, name='wishlist'),
path('wishlist/add/<int:id>/', views.add_to_wishlist, name='add_to_wishlist'),
path('wishlist/remove/<int:id>/', views.remove_wishlist, name='remove_wishlist'),
]
from django.contrib import admin
from .models import User, Cart, CartItem, Address, Order, OrderItem

admin.site.register(User)
admin.site.register(Cart)
admin.site.register(CartItem)
admin.site.register(Address)
admin.site.register(Order)
admin.site.register(OrderItem)
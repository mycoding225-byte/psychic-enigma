from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .forms import RegisterForm
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404
from home.models import Product
from .models import Cart, CartItem, Address, Order, OrderItem
from .forms import AddressForm
from .models import Wishlist



def register(request):
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        form = RegisterForm(request.POST)

        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()

            messages.success(
                request,
                "Account created successfully. Please login."
            )

            return redirect('/accounts/login/')
    else:
        form = RegisterForm()

    return render(
        request,
        'accounts/register.html',
        {'form': form}
    )


def login_page(request):
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:
            login(request, user)
            messages.success(request, f"Welcome {user.username}")
            return redirect('/')

        messages.error(request, "Invalid username or password")

    return render(request, 'accounts/login.html')


def logout_page(request):
    logout(request)
    messages.success(request, "Logged out successfully")
    return redirect('home')


@login_required
def cart(request):

    cart, created = Cart.objects.get_or_create(
        user=request.user
    )

    items = cart.items.all()

    total = sum(
        item.total_price()
        for item in items
    )

    return render(
        request,
        'accounts/cart.html',
        {
            'items': items,
            'total': total
        }
    )


@login_required(login_url='/accounts/login/')
def add_to_cart(request, product_id):

    product = get_object_or_404(
        Product,
        id=product_id
    )

    cart, created = Cart.objects.get_or_create(
        user=request.user
    )

    item, created = CartItem.objects.get_or_create(
        cart=cart,
        product=product
    )

    if not created:
        item.quantity += 1
        item.save()

    messages.success(
        request,
        "Product added to cart"
    )

    return redirect('cart')


@login_required
def remove_from_cart(request, item_id):

    item = get_object_or_404(
        CartItem,
        id=item_id,
        cart__user=request.user
    )

    item.delete()

    messages.success(
        request,
        "Item removed from cart"
    )

    return redirect('cart')


@login_required
def increase_quantity(request, item_id):
    item = get_object_or_404(
        CartItem,
        id=item_id,
        cart__user=request.user
    )

    item.quantity += 1
    item.save()

    return redirect('cart')


@login_required
def decrease_quantity(request, item_id):
    item = get_object_or_404(
        CartItem,
        id=item_id,
        cart__user=request.user
    )

    if item.quantity > 1:
        item.quantity -= 1
        item.save()
    else:
        item.delete()

    return redirect('cart')


@login_required
def checkout(request):

    cart, created = Cart.objects.get_or_create(user=request.user)
    items = cart.items.all()

    # Empty cart check
    if not items.exists():
        messages.error(request, "Your cart is empty.")
        return redirect("cart")

    total = sum(item.total_price() for item in items)

    # Get latest address
    address = Address.objects.filter(user=request.user).first()

    if not address:
        messages.warning(request, "Please add your shipping address first.")
        return redirect("shipping_address")

    if request.method == "POST":

        payment_method = request.POST.get("payment_method", "COD")

        # Create Order
        order = Order.objects.create(
            user=request.user,
            address=address,
            total_amount=total,
            payment_method=payment_method
        )

        # Save Order Items
        for item in items:

            # Stock check
            if item.product.stock < item.quantity:
                messages.error(
                    request,
                    f"{item.product.name} is out of stock."
                )
                order.delete()
                return redirect("cart")

            OrderItem.objects.create(
                order=order,
                product=item.product,
                quantity=item.quantity,
                price=item.product.price
            )

            # Reduce stock
            item.product.stock -= item.quantity
            item.product.save()

        # Empty cart
        items.delete()

        messages.success(
            request,
            "Your order has been placed successfully."
        )

        return redirect("my_orders")

    return render(
        request,
        "accounts/checkout.html",
        {
            "items": items,
            "total": total,
            "address": address,
        },
    )

@login_required
def my_orders(request):
    orders = Order.objects.filter(
        user=request.user
    ).order_by('-created_at')

    return render(
        request,
        'accounts/my_orders.html',
        {'orders': orders}
    )



@login_required
def address(request):

    address, created = Address.objects.get_or_create(
        user=request.user
    )

    if request.method == "POST":
        form = AddressForm(
            request.POST,
            instance=address
        )

        if form.is_valid():
            form.save()
            messages.success(
                request,
                "Profile updated successfully."
            )
            return redirect("checkout")

    else:
        form = AddressForm(
            instance=address
        )

    return render(
        request,
        "accounts/address.html",
        {
            "form": form
        }
    )


@login_required
def add_to_wishlist(request, id):
    product = get_object_or_404(Product, id=id)

    obj, created = Wishlist.objects.get_or_create(user=request.user, product=product)

    return redirect('wishlist')


@login_required
def remove_wishlist(request, id):
    Wishlist.objects.filter(user=request.user, product_id=id).delete()
    return redirect('wishlist')


@login_required
def wishlist(request):
    items = Wishlist.objects.filter(user=request.user)

    return render(request, "wishlist.html", {
        "items": items
    })


@login_required
def order_detail(request, order_id):

    order = get_object_or_404(
        Order,
        id=order_id,
        user=request.user
    )

    return render(
        request,
        'accounts/order_detail.html',
        {
            'order': order
        }
    )
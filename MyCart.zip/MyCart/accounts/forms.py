from django import forms
from .models import User
from .models import Address

class RegisterForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())

    class Meta:
        model = User
        fields = ['username', 'email', 'phone', 'password']




class AddressForm(forms.ModelForm):
    class Meta:
        model = Address
        exclude = ['user']